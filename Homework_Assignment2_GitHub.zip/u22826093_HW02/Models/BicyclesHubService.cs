﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class BicyclesHubService
    {
        /*
        private readonly BikeStoreContext dbContext;

        public BicyclesHubService(BikeStoreContext context)
        {
            dbContext = context;
        }

        public int GetTotalBicyclesListedThisMonth()
        {
            // Get the current month and year
            var currentMonth = DateTime.Now.Month;
            var currentYear = DateTime.Now.Year;

            // Assuming BICYCLE_CATEGORY_ID is 1 for bicycles
            const int BICYCLE_CATEGORY_ID = 1;

            // LINQ query to count bicycles listed this month
            var totalBicyclesListedThisMonth = dbContext.Products
                .Where(p => p.category_id == BICYCLE_CATEGORY_ID
                            && p.CreatedDate.Year == currentYear
                            && p.CreatedDate.Month == currentMonth)
                .Count();

            return totalBicyclesListedThisMonth;
        }
        */
    }
}