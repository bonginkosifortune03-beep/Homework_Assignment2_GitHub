﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class BrandSalesViewModel
    {
        public string BrandName { get; set; }
        public int SoldBicycles { get; set; }

    }
}