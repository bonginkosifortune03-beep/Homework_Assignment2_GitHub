﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class StoreViewModel
    {

        public string StoreName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string BicycleName { get; set; }
        public int Quantity { get; set; }
        public DateTime? OrderDate { get; set; }
        public string OrderStatus { get; set; }

    }
}