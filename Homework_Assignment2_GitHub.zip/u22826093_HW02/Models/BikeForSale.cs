﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class BikeForSale
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int BrandId { get; set; }
        public string BrandName { get; set; } // New property
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } // New property
        public decimal ListPrice { get; set; }
        public int Quantity { get; set; }
        public decimal Discount { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; } // New property
    }
}