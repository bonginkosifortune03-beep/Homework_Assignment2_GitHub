﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web;

namespace WebApplication5.Models
{

    //the model to for sellers
    public class SellerViewModel
    {
        public int StaffId { get; set; }
        public string StaffName { get; set; }  // Staff (seller) name
        public string Bicycle { get; set; }  // The bicycle being sold
        public string StoreName { get; set; }
     /*   public string StoreLocation { get; set; }  // Store location*/
        public DateTime OrderDate { get; set; }
        public int Quantity { get; set; }  // The quantity of bicycles in stock
    }

}