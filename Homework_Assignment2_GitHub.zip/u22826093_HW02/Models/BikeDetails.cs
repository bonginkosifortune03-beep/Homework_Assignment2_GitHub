﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class BikeDetails
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int BrandId { get; set; }
        /*public string BrandName { get; set; }  // Name of the brand, retrieved from the database*/
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }  // Name of the category, retrieved from the database
        public int ModelYear { get; set; }
        public decimal ListPrice { get; set; }
    }
}