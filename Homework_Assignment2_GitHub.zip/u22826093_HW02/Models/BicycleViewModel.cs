﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class BicycleViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ModelYear { get; set; }
        public decimal ListPrice { get; set; }
        public string BrandName { get; set; }
        public string CategoryName { get; set; }

        //newly added
        public string StaffFirstName { get; set; }
        public string StaffLastName { get; set; }
        public string StaffEmail { get; set; }
        public string StaffPhone { get; set; }
        public string BicycleName { get; set; }
        public int Quantity { get; set; }
        public int StoreId { get; set; }

    }
}