﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class OrderViewModel
    {
        public int CustomerId { get; set; }
        public int StoreId { get; set; }
        public int StaffId { get; set; }
        public DateTime RequiredDate { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}