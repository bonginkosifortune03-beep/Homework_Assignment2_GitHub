﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class Register
    {
        public string UserName { get; set; }
        public string Role { get; set; }
        public HttpPostedFileBase ProfilePicture { get; set; }

        // Buyer-specific fields
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }

        // Seller-specific fields
        public byte ActiveStatus { get; set; }
        public int StoreId { get; set; }
        public int? ManagerId { get; set; } // Nullable, as it may not always be provided
    }


}