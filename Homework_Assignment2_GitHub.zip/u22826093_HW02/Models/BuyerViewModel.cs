﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace WebApplication5.Models
{
    public class BuyerViewModel
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string StoreName { get; set; }
        public DateTime OrderDate { get; set; }
        public string StaffName { get; set; }
    }
}