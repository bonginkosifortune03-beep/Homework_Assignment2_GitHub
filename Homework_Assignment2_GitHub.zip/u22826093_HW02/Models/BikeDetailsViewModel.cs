﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class BikeDetailsViewModel
    {
        public int OrderId { get; set; }
        public string BicycleName { get; set; }
        public int Quantity { get; set; }
        public decimal ListPrice { get; set; }
        public decimal Discount { get; set; }
        public DateTime OrderDate { get; set; }
        public string OrderStatus { get; set; }
        public string StoreName { get; set; }
        public string StaffFirstName { get; set; }
        public string StaffLastName { get; set; }
    }
}