# Homework Assignment 2: Bicycle Store Web Application

ASP.NET MVC (C#) web application built on the **BikeStores** SQL Server sample database.
Users can register and log in, browse bicycles by brand (Electra, Haro, Heller, Trek, Surly and others),
search by price range, buy and sell bikes, and view summary reports such as sales per brand,
totals per store and new stock.

## Built with
- ASP.NET MVC 5, C#, Razor views
- SQL Server (Express), using the BikeStores database
- Bootstrap and jQuery

## How to run
1. Run `BikeStores.sql` in SQL Server Management Studio to create the database.
2. Open `WebApplication5.sln` in Visual Studio.
3. Update the connection string in `Web.config` to point to your SQL Server instance.
4. Right-click the solution, choose **Restore NuGet Packages**, then press **F5**.

## Author
Tlou Bonginkosi Fortune
