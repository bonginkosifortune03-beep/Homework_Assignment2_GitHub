﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Controllers
{ 
    public class Globals
    {
        /*here i am creating my connection string*/
        public static string ConnectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

    }
    
}