﻿using Microsoft.Ajax.Utilities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using WebApplication5.Models;
using static WebApplication5.Models.Register;

namespace WebApplication5.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            /*ViewBag.Message = "Your application description page.";*/

            return View();
        }

        public ActionResult Buy()
        {
            /*  ViewBag.Message = "Your contact page.";*/

            return View();
        }

        
        public ActionResult Register()
        {

            return View();
        }

        public ActionResult Sell()
        {
            /*ViewBag.Message = "Your application description page.";*/

            return View();
        }

        public ActionResult Bikes()
        {
            return View();
        }


        //method to To Register
        [HttpPost]
        public ActionResult DoInsert(Register model)
        {
            try
            {
                // Connection string to your SQL Server instance
                string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

                using (SqlConnection myConnection = new SqlConnection(connectionString))
                {
                    // Convert the uploaded file to a byte array
                    byte[] profilePictureBytes = null;
                    if (model.ProfilePicture != null && model.ProfilePicture.ContentLength > 0)
                    {
                        using (var binaryReader = new BinaryReader(model.ProfilePicture.InputStream))
                        {
                            profilePictureBytes = binaryReader.ReadBytes(model.ProfilePicture.ContentLength);
                        }
                    }

                    //opening connections
                    myConnection.Open();
                    SqlCommand myInsertCommand = null;

                    if (model.Role == "Buyer" || model.Role == "Both")
                    {
                        // Insert into sales.customers for buyers
                        string buyerQuery = "INSERT INTO sales.customers (first_name, last_name, phone, email, street, city, state, zip_code) " +
                                            "VALUES (@first_name, @last_name, @phone, @Email, @Street, @City, @State, @ZipCode)";
                        myInsertCommand = new SqlCommand(buyerQuery, myConnection);
                        myInsertCommand.Parameters.AddWithValue("@first_name", model.FirstName);
                        myInsertCommand.Parameters.AddWithValue("@last_name", model.LastName);
                        myInsertCommand.Parameters.AddWithValue("@phone", (object)model.Phone ?? DBNull.Value);
                        myInsertCommand.Parameters.AddWithValue("@Email", model.Email);
                        myInsertCommand.Parameters.AddWithValue("@Street", (object)model.Street ?? DBNull.Value);
                        myInsertCommand.Parameters.AddWithValue("@City", (object)model.City ?? DBNull.Value);
                        myInsertCommand.Parameters.AddWithValue("@State", (object)model.State ?? DBNull.Value);
                        myInsertCommand.Parameters.AddWithValue("@ZipCode", (object)model.ZipCode ?? DBNull.Value);
                        myInsertCommand.ExecuteNonQuery();
                    }

                    if (model.Role == "Seller" || model.Role == "Both")
                    {
                        // Insert into sales.staffs for sellers
                        string sellerQuery = "INSERT INTO sales.staffs (first_name, last_name, email, phone, active, store_id, manager_id) " +
                                             "VALUES (@first_name, @last_name, @Email, @Phone, @Active, @StoreId, @ManagerId)";
                        myInsertCommand = new SqlCommand(sellerQuery, myConnection);
                        myInsertCommand.Parameters.AddWithValue("@first_name", model.FirstName);
                        myInsertCommand.Parameters.AddWithValue("@last_name", model.LastName);
                        myInsertCommand.Parameters.AddWithValue("@Email", model.Email);
                        myInsertCommand.Parameters.AddWithValue("@Phone", (object)model.Phone ?? DBNull.Value);
                        myInsertCommand.Parameters.AddWithValue("@Active", model.ActiveStatus);
                        myInsertCommand.Parameters.AddWithValue("@StoreId", model.StoreId);
                        myInsertCommand.Parameters.AddWithValue("@ManagerId", (object)model.ManagerId ?? DBNull.Value);
                        myInsertCommand.ExecuteNonQuery();
                    }

                    ViewBag.Message = "You are now registered!";
                }
            }
            catch (Exception err)
            {
                ViewBag.Message = "Error: " + err.Message;
            }

            // Redirect or return to the same view with a message
            return View("Register");
        }
       


       


        /*view for all the brand bikes*/
        public ActionResult Electra(List<Product> products)
        {
            return View(products); // Pass the filtered products to the Electra view
        }
        public ActionResult Haro()
        {
            return View();
        }
        public ActionResult Heller()
        {
            return View();
        }

        public ActionResult Trek()
        {
            return View();
        }

        public ActionResult Pure_Cycles()
        {
            return View();
        }

        public ActionResult Ritchey()
        {
            return View();
        }

        public ActionResult Sun_Bicycles()
        {
            return View();
        }

        public ActionResult Surly()
        {
            return View();
        }

        public ActionResult Strider()
        {
            return View();
        }


        //Creating a method that will be a filter to the for Different Bike Brands

        /*Filtering for different biycle brands*/
        public JsonResult MultiWhereClause(string filter)  
        {
            List<Product> products = new List<Product>();  //this is list that will be populated when data is retrived 

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define different queries based on the filter value
                    if (filter == "cruiser1")
                    {
                        // Query for Electra Cruiser 1
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 1 AND category_id = 3";
                    }
                    else if (filter == "cruiser2")
                    {
                        // Query for Electra Cruiser 2
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 1 AND category_id = 2";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);  // Return the list of products as JSON
        }

        //this method is to get infomation for a particular brand
        public JsonResult MultiWhereClauseForHaro(string filter)
        {
            List<Product> products = new List<Product>();

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define different queries based on the filter value
                    if (filter == "haro1")
                    {
                        // Query for Haro Bicycle with brand_id = 2 and category_id = 6
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 2 AND category_id = 6";
                    }
                    else if (filter == "haro2")
                    {
                        // Query for Haro Bicycle with brand_id = 2 and category_id = 1
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 2 AND category_id = 1";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);
        }

        //this is the method to retrieve bicycle for heller
        public JsonResult MultiWhereClauseForHeller(string filter)
        {
            List<Product> products = new List<Product>();

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define different queries based on the filter value
                    if (filter == "heller1")
                    {
                        // Query for Heller Bicycle with brand_id = 3 and category_id = 6
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 3 AND category_id = 6";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);
        }


        //this the method to filter and retrieve details about Trek Bicycle
        public JsonResult MultiWhereClauseForTrek(string filter)
        {
            List<Product> products = new List<Product>();

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define different queries based on the filter value
                    if (filter == "trek1")
                    {
                        // Query for Trek Bicycle with brand_id = 6, 7, or 1 and category_id = 5
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                         WHERE (category_id = 6 OR category_id = 7 OR category_id= 1 ) 
                           AND brand_id = 9";
                    }
                    else if (filter == "trek2")
                    {
                        // Query for Trek Bicycle with brand_id = 6, 7, or 1 and category_id = 4
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE (category_id = 4 OR category_id = 5 ) 
                           AND brand_id = 9";

                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);
        }

        //this is the method for retrieving information for Pure Cycle bicycle
        public JsonResult MultiWhereClauseForPureCycle(string filter)
        {
            List<Product> products = new List<Product>();

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define different queries based on the filter value
                    if (filter == "purecycle1")
                    {
                        // Query for Pure Cycle Bicycle with brand_id = 4 and category_id = 3
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 4 AND category_id = 3";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);
        }

        //this is the method that will retriec informatiobn about the Ritchey bicycle
        public JsonResult MultiWhereClauseForRitchey(string filter)
        {
            List<Product> products = new List<Product>();

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define the query based on the filter value
                    if (filter == "ritchey1")
                    {
                        // Query for Ritchey Bicycle with brand_id = 5 and category_id = 6
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 5 AND category_id = 6";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);
        }

        //this is the method that will retriev infomation about Sun Bicycle
        public JsonResult MultiWhereClauseForSun(string filter)
        {
            List<Product> products = new List<Product>();

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define the query based on the filter value
                    if (filter == "sun1")
                    {
                        // Query for Sun Bicycle with brand_id = 7 and category_id in (6, 1, 2)
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 7 AND category_id IN (6, 1, 2)";
                    }
                    else if (filter == "sun2")
                    {
                        // Query for Sun Bicycle with brand_id = 7 and category_id in (5, 3)
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 7 AND category_id IN (5, 3)";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);
        }

        //this is method that will retrieve infomation about the Surly bicyle
        public JsonResult MultiWhereClauseForSurly(string filter)
        {
            List<Product> products = new List<Product>();

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define the query based on the filter value
                    if (filter == "surly1")
                    {
                        // Query for Surly Bicycle with brand_id = 8 and category_id in (6, 7)
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 8 AND category_id IN (6, 7)";
                    }
                    else if (filter == "surly2")
                    {
                        // Query for Surly Bicycle with brand_id = 7 and category_id = 4
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 8 AND category_id = 4";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);
        }

        //this is method to retrive information about the Strider Bicylce
        public JsonResult MultiWhereClauseForStrider(string filter)
        {
            List<Product> products = new List<Product>();

            string connectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string query = "";

                    // Define the query based on the filter value
                    if (filter == "strider")
                    {
                        // Query for Strider Bicycle with brand_id = 6 and category_id = 1
                        query = @"SELECT product_name, brand_id, category_id, model_year, list_price 
                          FROM production.products 
                          WHERE brand_id = 6 AND category_id = 1";
                    }

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            Product product = new Product
                            {
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt16(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"])
                            };
                            products.Add(product);
                        }
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    // Return an error message
                    return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
                }
                finally
                {
                    con.Close();
                }
            }

            return Json(new { success = true, products }, JsonRequestBehavior.AllowGet);
        }








        public ActionResult Buyers()
        {
            return View();
        }

        //method to retrieve all the buyers 
        public ActionResult GetBuyers()
        {
            List<BuyerViewModel> buyers = new List<BuyerViewModel>();
            string connectionString = Globals.ConnectionString;

            SqlConnection con = new SqlConnection(connectionString);

            try
            {
                SqlCommand cmd = new SqlCommand(@"
        SELECT c.customer_id, c.first_name AS customer_first_name, c.last_name AS customer_last_name, 
               s.store_name, o.order_date, st.first_name AS staff_first_name, st.last_name AS staff_last_name
        FROM BikeStores.sales.orders o
        JOIN BikeStores.sales.customers c ON o.customer_id = c.customer_id
        JOIN BikeStores.sales.staffs st ON o.staff_id = st.staff_id
        JOIN BikeStores.sales.stores s ON o.store_id = s.store_id
        ORDER BY o.order_date DESC", con);

                con.Open();
                SqlDataReader Reader = cmd.ExecuteReader();

                if (!Reader.HasRows)
                {
                    ViewBag.Message = "No results found.";
                    return View("Buyers", buyers);  // Return the Buyers view with an empty list
                }

                while (Reader.Read())
                {
                    BuyerViewModel buyer = new BuyerViewModel
                    {
                        CustomerId = Convert.ToInt32(Reader["customer_id"]),
                        CustomerName = Reader["customer_first_name"].ToString() + " " + Reader["customer_last_name"].ToString(),
                        StoreName = Reader["store_name"].ToString(),
                        OrderDate = Convert.ToDateTime(Reader["order_date"]),
                        StaffName = Reader["staff_first_name"].ToString() + " " + Reader["staff_last_name"].ToString()
                    };
                    buyers.Add(buyer);
                }

                Reader.Close();
                ViewBag.Message = "Success: Data retrieved.";
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Error: {ex.Message}";
            }
            finally
            {
                con.Close();
            }

            return View("Buyers", buyers);  // Return the Buyers view with the list of buyers
        }

        //the view for the sellers
        public ActionResult Sellers()
        {
            return View();
        }

        //the mothods to get all the sellers
        public ActionResult GetSellers()
        {
            List<SellerViewModel> sellers = new List<SellerViewModel>();
            string connectionString = Globals.ConnectionString;

            SqlConnection con = new SqlConnection(connectionString);

            try
            {
                // SQL query to retrieve the first 1000 sellers (staff), bicycle details, and store information for stores in South Africa
                string sqlQuery = @"
        SELECT TOP 1000 st.staff_id, st.first_name AS staff_first_name, st.last_name AS staff_last_name,
               pr.product_name AS bicycle_name, s.store_name, o.order_date, ps.quantity
        FROM BikeStores.sales.orders o
        JOIN BikeStores.sales.staffs st ON o.staff_id = st.staff_id
        JOIN BikeStores.sales.stores s ON o.store_id = s.store_id
        JOIN BikeStores.production.stocks ps ON s.store_id = ps.store_id
        JOIN BikeStores.production.products pr ON ps.product_id = pr.product_id
          AND ps.quantity > 0
        ORDER BY o.order_date DESC";

                SqlCommand cmd = new SqlCommand(sqlQuery, con);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (!reader.HasRows)
                {
                    ViewBag.Message = "No sellers (staff) found.";
                    return View("Sellers", sellers);  // Return Sellers view with an empty list
                }

                while (reader.Read())
                {
                    SellerViewModel seller = new SellerViewModel
                    {
                        StaffId = Convert.ToInt32(reader["staff_id"]),
                        StaffName = reader["staff_first_name"].ToString() + " " + reader["staff_last_name"].ToString(),
                        Bicycle = reader["bicycle_name"].ToString(),
                        StoreName = reader["store_name"].ToString(),

                        OrderDate = Convert.ToDateTime(reader["order_date"]),
                        Quantity = Convert.ToInt32(reader["quantity"])
                    };
                    sellers.Add(seller);
                }

                reader.Close();
                ViewBag.Message = "Success: Data retrieved.";
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Error: {ex.Message}";
            }
            finally
            {
                con.Close();
            }

            return View("Sellers", sellers);  // Return the Sellers view with the list of sellers (staff)
        }

        //the view for the stores
        public ActionResult Stores()
        {
            return View();
        }

        //the method to get all stores
        public ActionResult GetStores()
        {
            List<StoreViewModel> stores = new List<StoreViewModel>();
            string connectionString = Globals.ConnectionString;

            SqlConnection con = new SqlConnection(connectionString);

            try
            {
                string sqlQuery = @"
        SELECT s.store_name, s.phone, s.email, s.street, s.city, s.state, s.zip_code,
               p.product_name AS bicycle_name, st.quantity, o.order_date, o.order_status
        FROM BikeStores.sales.stores s
        JOIN BikeStores.production.stocks st ON s.store_id = st.store_id
        JOIN BikeStores.production.products p ON st.product_id = p.product_id
        LEFT JOIN BikeStores.sales.orders o ON s.store_id = o.store_id AND o.order_status = 1
        ORDER BY p.product_name";

                SqlCommand cmd = new SqlCommand(sqlQuery, con);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (!reader.HasRows)
                {
                    ViewBag.Message = "No bicycles found.";
                    return View("Stores", stores);  // Return Stores view with an empty list
                }

                while (reader.Read())
                {
                    StoreViewModel store = new StoreViewModel
                    {
                        StoreName = reader["store_name"].ToString(),
                        Phone = reader["phone"].ToString(),
                        Email = reader["email"].ToString(),
                        Address = $"{reader["street"]}, {reader["city"]}, {reader["state"]}, {reader["zip_code"]}",
                        BicycleName = reader["bicycle_name"].ToString(),
                        Quantity = Convert.ToInt32(reader["quantity"]),
                        OrderDate = reader["order_date"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["order_date"]),
                        OrderStatus = reader["order_status"] == DBNull.Value ? null : reader["order_status"].ToString()
                    };
                    stores.Add(store);
                }

                reader.Close();
                ViewBag.Message = "Success: Data retrieved.";
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Error: {ex.Message}";
            }
            finally
            {
                con.Close();
            }

            return View("Stores", stores);  // Return the Stores view with the list of stores and bicycles
        }

        //the view for the prices 
        public ActionResult Prices()
        {
            return View();
        }

        public ActionResult GetBicyclesByPriceRange(decimal? minPrice, decimal? maxPrice)
        {
            List<BicycleViewModel> bicycles = new List<BicycleViewModel>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // Query to get bicycles within the specified price range
                    string sqlQuery = @"
                SELECT p.product_id, p.product_name, p.model_year, p.list_price, b.brand_name, c.category_name
                FROM BikeStores.production.products p
                JOIN BikeStores.production.brands b ON p.brand_id = b.brand_id
                JOIN BikeStores.production.categories c ON p.category_id = c.category_id
                WHERE p.list_price BETWEEN @minPrice AND @maxPrice
                ORDER BY p.list_price";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);

                    // Set parameters with user input
                    cmd.Parameters.AddWithValue("@minPrice", minPrice.HasValue ? minPrice.Value : 0);
                    cmd.Parameters.AddWithValue("@maxPrice", maxPrice.HasValue ? maxPrice.Value : decimal.MaxValue);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (!reader.HasRows)
                    {
                        ViewBag.Message = "No bicycles found in the specified price range.";
                        return View("Prices", bicycles);  // Return the Prices view with an empty list
                    }

                    // Fetch and populate the list of bicycles
                    while (reader.Read())
                    {
                        BicycleViewModel bicycle = new BicycleViewModel
                        {
                            ProductId = Convert.ToInt32(reader["product_id"]),
                            ProductName = reader["product_name"].ToString(),
                            ModelYear = Convert.ToInt32(reader["model_year"]),
                            ListPrice = Convert.ToDecimal(reader["list_price"]),
                            BrandName = reader["brand_name"].ToString(),
                            CategoryName = reader["category_name"].ToString()
                        };
                        bicycles.Add(bicycle);
                    }

                    reader.Close();
                    ViewBag.Message = "Bicycles retrieved successfully.";
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            return View("Prices", bicycles);  // Return the Prices view with the list of bicycles
        }




        //view to return bicycle in certain price range when selected 
        public ActionResult GetBicycleDetails(int productId)
        {
            BicycleViewModel bicycle = null;
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
                SELECT p.product_id, p.product_name, p.model_year, p.list_price, b.brand_name, c.category_name
                FROM BikeStores.production.products p
                JOIN BikeStores.production.brands b ON p.brand_id = b.brand_id
                JOIN BikeStores.production.categories c ON p.category_id = c.category_id
                WHERE p.product_id = @productId";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.Parameters.AddWithValue("@productId", productId);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        bicycle = new BicycleViewModel
                        {
                            ProductId = Convert.ToInt32(reader["product_id"]),
                            ProductName = reader["product_name"].ToString(),
                            ModelYear = Convert.ToInt32(reader["model_year"]),
                            ListPrice = Convert.ToDecimal(reader["list_price"]),
                            BrandName = reader["brand_name"].ToString(),
                            CategoryName = reader["category_name"].ToString()
                        };
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            if (bicycle == null)
            {
                return HttpNotFound();
            }

            return View("BicycleDetails", bicycle);
        }



        //this is the view for the new stock
        public ActionResult NewStocksSummary()
        {
            return View();
        }

        //the method that will return the total number of new stock
        public ActionResult GetNewStockCount()
        {
            int totalNewStocks = 0;
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
                    SELECT COUNT(*) AS TotalNewStocks
                    FROM BikeStores.production.products
                    ";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    totalNewStocks = Convert.ToInt32(cmd.ExecuteScalar());

                    ViewBag.Message = totalNewStocks > 0
                        ? $"Total bicycles listed this month: {totalNewStocks}"
                        : "No new bicycles listed this month.";
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            ViewBag.TotalNewStocks = totalNewStocks;
            return View("NewStocksSummary");
        }

        //a view to diplay used to diplay the list for sale new stock
        public ActionResult BicyclesAvailableSummary()
        {
            return View();
        }

        //this method used to get the total number bicycle that is listed for the sale
        public ActionResult GetTotalBicyclesAvailable()
        {
            int totalBicyclesAvailable = 0;
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
                SELECT SUM(quantity) AS TotalBicyclesAvailable
                FROM BikeStores.production.stocks;";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    totalBicyclesAvailable = Convert.ToInt32(cmd.ExecuteScalar());

                    ViewBag.Message = totalBicyclesAvailable > 0
                        ? $"Total bicycles available for sale: {totalBicyclesAvailable}"
                        : "No bicycles available for sale.";
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            ViewBag.TotalBicyclesAvailable = totalBicyclesAvailable;
            return View("BicyclesAvailableSummary");
        }


        //A view for thr total bicycle sold
        public ActionResult BicyclesSoldSummary()
        {
            return View();
        }
        //this a method that calculates the total of bicycle sold
        public ActionResult GetTotalBicyclesSold()
        {
            int totalBicyclesSold = 0;
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
                SELECT SUM(quantity) AS TotalBicyclesSold
                FROM BikeStores.sales.order_items;";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    totalBicyclesSold = Convert.ToInt32(cmd.ExecuteScalar());

                    ViewBag.Message = totalBicyclesSold > 0
                        ? $"Total bicycles sold: {totalBicyclesSold}"
                        : "No bicycles sold so far.";
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            ViewBag.TotalBicyclesSold = totalBicyclesSold;
            return View("BicyclesSoldSummary");
        }


        //view that display brand total sold
        public ActionResult SalesPerBrandSummary()
        {
            return View();
        }



        //this method returns bikes sold per brand
        public ActionResult GetSalesPerBrand()
        {
            List<BrandSalesViewModel> brandSalesList = new List<BrandSalesViewModel>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
                SELECT 
                    b.brand_name,
                    COUNT(oi.product_id) AS sold_bicycles
                FROM 
                    [BikeStores].[production].[products] p
                JOIN 
                    [BikeStores].[sales].[order_items] oi ON p.product_id = oi.product_id
                JOIN 
                    [BikeStores].[sales].[orders] o ON oi.order_id = o.order_id
                JOIN 
                    [BikeStores].[production].[brands] b ON p.brand_id = b.brand_id
                WHERE 
                    o.order_status BETWEEN 1 AND 4
                GROUP BY 
                    b.brand_name
                ORDER BY 
                    sold_bicycles DESC;";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        BrandSalesViewModel brandSales = new BrandSalesViewModel
                        {
                            BrandName = reader["brand_name"].ToString(),
                            SoldBicycles = Convert.ToInt32(reader["sold_bicycles"])
                        };

                        brandSalesList.Add(brandSales);
                    }

                    reader.Close();
                    ViewBag.Message = brandSalesList.Count > 0
                        ? "Sales per brand retrieved successfully."
                        : "No sales data found for brands.";
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            return View("SalesPerBrandSummary", brandSalesList);
        }

        //this is the view for the brand total 
        public ActionResult SalesPerBrand()
        {
            return View();
        }

        //this is the method that i use to get the total for each brannd
        public ActionResult GetBicyclesPerBrand()
        {
            Dictionary<string, int> bicyclesPerBrand = new Dictionary<string, int>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT b.brand_name, COUNT(p.product_id) AS TotalBicyclesAvailable
            FROM production.products p
            JOIN production.brands b ON p.brand_id = b.brand_id
            GROUP BY b.brand_name;";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string brandName = reader["brand_name"].ToString();
                            int totalBicyclesAvailable = Convert.ToInt32(reader["TotalBicyclesAvailable"]);
                            bicyclesPerBrand.Add(brandName, totalBicyclesAvailable);
                        }
                    }

                    if (bicyclesPerBrand.Count > 0)
                    {
                        ViewBag.Message = "Bicycles available per brand:";
                        ViewBag.BicyclesPerBrand = bicyclesPerBrand;
                    }
                    else
                    {
                        ViewBag.Message = "No bicycles available.";
                        ViewBag.BicyclesPerBrand = null;  //  set to null to indicate no data.
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                    ViewBag.BicyclesPerBrand = null;
                }
            }

            return View("SalesPerBrand");
        }

        //this is the view to diplay the averages per brand
        public ActionResult AverageSalePerBrandSummary()
        {
            return View();
        }

        //this is the method that i used to get the average for each brand 
        public ActionResult GetAverageSalePerBrand()
        {
            Dictionary<string, decimal> averageSalePerBrand = new Dictionary<string, decimal>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT b.brand_name, AVG(oi.list_price) AS AveragePrice
            FROM sales.order_items oi
            JOIN production.products p ON oi.product_id = p.product_id
            JOIN production.brands b ON p.brand_id = b.brand_id
            GROUP BY b.brand_name;";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string brandName = reader["brand_name"].ToString();
                            decimal averagePrice = Convert.ToDecimal(reader["AveragePrice"]);
                            averageSalePerBrand.Add(brandName, averagePrice);
                        }
                    }

                    ViewBag.Message = averageSalePerBrand.Count > 0
                        ? "Average sale price per brand:"
                        : "No sales data available.";

                    ViewBag.AverageSalePerBrand = averageSalePerBrand.Any() ? averageSalePerBrand : null;
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                    ViewBag.AverageSalePerBrand = null;
                }
            }

            return View("AverageSalePerBrandSummary");
        }

        //view to return totalper brand
        public ActionResult TotalsPerBrandCategorySummary()
        {
            return View();
        }


        //this is the method used to get the totals for each brand
        public ActionResult GetTotalsPerBrandCategory()
        {
            Dictionary<string, Dictionary<string, int>> totalsPerBrandCategory = new Dictionary<string, Dictionary<string, int>>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT b.brand_name, c.category_name, COUNT(p.product_id) AS TotalBicycles
            FROM production.products p
            JOIN production.brands b ON p.brand_id = b.brand_id
            JOIN production.categories c ON p.category_id = c.category_id
            GROUP BY b.brand_name, c.category_name;";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string brandName = reader["brand_name"].ToString();
                            string categoryName = reader["category_name"].ToString();
                            int totalBicycles = Convert.ToInt32(reader["TotalBicycles"]);

                            if (!totalsPerBrandCategory.ContainsKey(brandName))
                            {
                                totalsPerBrandCategory[brandName] = new Dictionary<string, int>();
                            }

                            totalsPerBrandCategory[brandName][categoryName] = totalBicycles;
                        }
                    }

                    ViewBag.Message = totalsPerBrandCategory.Count > 0
                        ? "Bicycles count per brand and category:"
                        : "No data available.";

                    ViewBag.TotalsPerBrandCategory = totalsPerBrandCategory.Any() ? totalsPerBrandCategory : null;
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                    ViewBag.TotalsPerBrandCategory = null;
                }
            }

            return View("TotalsPerBrandCategorySummary");
        }

        //view to return all the total based on the stor
        public ActionResult TotalsPerStoreSummary()
        {
            return View();
        }

        public ActionResult GetTotalsPerStore()
        {
            Dictionary<string, int> totalsPerStore = new Dictionary<string, int>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT s.store_name, COUNT(p.product_id) AS TotalBicycles
            FROM production.stocks st
            JOIN sales.stores s ON st.store_id = s.store_id
            JOIN production.products p ON st.product_id = p.product_id
            GROUP BY s.store_name;";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string storeName = reader["store_name"].ToString();
                            int totalBicycles = Convert.ToInt32(reader["TotalBicycles"]);
                            totalsPerStore.Add(storeName, totalBicycles);
                        }
                    }

                    ViewBag.Message = totalsPerStore.Count > 0
                        ? "Bicycles count per store:"
                        : "No data available.";

                    ViewBag.TotalsPerStore = totalsPerStore.Any() ? totalsPerStore : null;
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                    ViewBag.TotalsPerStore = null;
                }
            }

            return View("TotalsPerStoreSummary");
        }


        //authentication method
        public User AuthenticateUser(string userName, string inputRole)
        {
            User user = new User { UserName = userName, Role = "" };

            using (SqlConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                connection.Open();

                // Check if user is a Buyer (Customer)
                string buyerQuery = "SELECT customer_id FROM [sales].[customers] WHERE first_name = @userName";
                using (SqlCommand buyerCommand = new SqlCommand(buyerQuery, connection))
                {
                    buyerCommand.Parameters.AddWithValue("@userName", userName);
                    var customerId = buyerCommand.ExecuteScalar();
                    if (customerId != null)
                    {
                        user.Role = "buyer";
                    }
                }

                // Check if user is a Seller (Staff)
                string sellerQuery = "SELECT staff_id FROM [sales].[staffs] WHERE first_name = @userName";
                using (SqlCommand sellerCommand = new SqlCommand(sellerQuery, connection))
                {
                    sellerCommand.Parameters.AddWithValue("@userName", userName);
                    var staffId = sellerCommand.ExecuteScalar();
                    if (staffId != null)
                    {
                        user.Role = user.Role == "buyer" ? "both" : "seller";
                    }
                }
            }

            // Validate role selection against the database results
            if (!user.Role.Equals(inputRole, StringComparison.OrdinalIgnoreCase))
            {
                user = null;
            }

            return user;
        }


        //log in method
        [HttpPost]
        public ActionResult Login(string userName, string inputRole)
        {
            var user = AuthenticateUser(userName, inputRole);

            if (user != null) // If user is authenticated
            {
                Session["UserRole"] = user.Role; // Store user role in session
                Session["IsLoggedIn"] = true;
                Session["IsSeller"] = user.Role.Contains("seller");
                Session["IsBuyer"] = user.Role.Contains("buyer");

                return RedirectToAction("Index", "Home"); // Redirect after successful login
            }
            else
            {
                ViewBag.Error = "Invalid username or role. Please try again.";
                return View(); // Return to the login view if authentication fails
            }
        }

        //this is a add view
        [HttpGet]
        public ActionResult AddBike()
        {
            // Fetch brand and category options from the database
            using (SqlConnection connection = new SqlConnection(Globals.ConnectionString))
            {
                connection.Open();

                // Fetch brands
                string brandQuery = "SELECT brand_id, brand_name FROM production.brands";
                SqlCommand brandCommand = new SqlCommand(brandQuery, connection);
                SqlDataReader brandReader = brandCommand.ExecuteReader();
                List<SelectListItem> brands = new List<SelectListItem>();
                while (brandReader.Read())
                {
                    brands.Add(new SelectListItem
                    {
                        Value = brandReader["brand_id"].ToString(),
                        Text = brandReader["brand_name"].ToString()
                    });
                }
                brandReader.Close();

                // Fetch categories
                string categoryQuery = "SELECT category_id, category_name FROM production.categories";
                SqlCommand categoryCommand = new SqlCommand(categoryQuery, connection);
                SqlDataReader categoryReader = categoryCommand.ExecuteReader();
                List<SelectListItem> categories = new List<SelectListItem>();
                while (categoryReader.Read())
                {
                    categories.Add(new SelectListItem
                    {
                        Value = categoryReader["category_id"].ToString(),
                        Text = categoryReader["category_name"].ToString()
                    });
                }

                ViewBag.Brands = brands;
                ViewBag.Categories = categories;
            }

            return View();
        }

        [HttpPost]
        public ActionResult AddBike(Product model, HttpPostedFileBase imageFile)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection connection = new SqlConnection(Globals.ConnectionString))
                {
                    string query = @"INSERT INTO [production].[products] 
                            (product_name, brand_id, category_id, model_year, list_price) 
                            VALUES (@ProductName, @BrandId, @CategoryId, @ModelYear, @ListPrice)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductName", model.ProductName);
                        command.Parameters.AddWithValue("@BrandId", model.BrandId);
                        command.Parameters.AddWithValue("@CategoryId", model.CategoryId);
                        command.Parameters.AddWithValue("@ModelYear", model.ModelYear);
                        command.Parameters.AddWithValue("@ListPrice", model.ListPrice);
                        /*
                        if (imageFile != null && imageFile.ContentLength > 0)
                        {
                            byte[] imageData = null;
                            using (var binaryReader = new BinaryReader(imageFile.InputStream))
                            {
                                imageData = binaryReader.ReadBytes(imageFile.ContentLength);
                            }
                            command.Parameters.AddWithValue("@Image", imageData);
                        }
                        else
                        {
                            command.Parameters.AddWithValue("@Image", DBNull.Value);
                        }
                        */
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
                return RedirectToAction("Index"); // Redirect after successful submission
            }

            // Fetch the dropdown data again in case of validation errors
            AddBike();
            return View(model); // Return to view if validation fails
        }
        /*
        //this view update the bikes that were added
        public ActionResult UpdateBike()
        {
            return View();
        }
        */

        //these methods handle the updatae


        // GET: Update
        public ActionResult UpdateBike()
        {
            return View();
        }

        // POST: DoUpdate
        [HttpPost]
        public ActionResult DoUpdate(int id, string productName, int brandId, int categoryId, int modelYear, decimal listPrice)
        {
            // Validate the input parameters
            if (modelYear <= 0 || listPrice <= 0)
            {
                ViewBag.Message = "Error: Model Year and List Price cannot be zero or negative.";
                return View("Index");
            }

            try
            {
                // Connection string to your SQL Server instance
                string connectionString = Globals.ConnectionString; // Assume this is your connection string variable

                using (SqlConnection myConnection = new SqlConnection(connectionString))
                {
                    // Query to update data in the database
                    string query = @"UPDATE [production].[products] 
                                 SET product_name = @ProductName, 
                                     brand_id = @BrandId, 
                                     category_id = @CategoryId, 
                                     model_year = @ModelYear, 
                                     list_price = @ListPrice 
                                 WHERE product_id = @ID";
                    SqlCommand myUpdateCommand = new SqlCommand(query, myConnection);

                    // Adding parameters to avoid SQL injection
                    myUpdateCommand.Parameters.AddWithValue("@ProductName", productName);
                    myUpdateCommand.Parameters.AddWithValue("@BrandId", brandId);
                    myUpdateCommand.Parameters.AddWithValue("@CategoryId", categoryId);
                    myUpdateCommand.Parameters.AddWithValue("@ModelYear", modelYear);
                    myUpdateCommand.Parameters.AddWithValue("@ListPrice", listPrice);
                    myUpdateCommand.Parameters.AddWithValue("@ID", id);

                    // Opening the connection and executing the command
                    myConnection.Open();
                    int rowsAffected = myUpdateCommand.ExecuteNonQuery();
                    ViewBag.Message = "Success: " + rowsAffected + " rows updated.";
                }
            }
            catch (SqlException sqlEx)
            {
                ViewBag.Message = "SQL Error: " + sqlEx.Message;
            }
            catch (Exception ex)
            {
                ViewBag.Message = "General Error: " + ex.Message;
            }

            return View("Index"); // Redirect to the Index view after the update
        }



        // GET: Delete
        public ActionResult Delete()
        {
            return View();
        }

        // POST: DoDelete
        [HttpPost]
        public ActionResult DoDelete(int id)
        {
            try
            {
                // Connection string to your SQL Server instance
                string connectionString = Globals.ConnectionString; // Assume this is your connection string variable

                using (SqlConnection myConnection = new SqlConnection(connectionString))
                {
                    // Query to delete data in the database
                    SqlCommand myDeleteCommand = new SqlCommand("DELETE FROM [production].[products] WHERE product_id = @ID", myConnection);
                    myDeleteCommand.Parameters.AddWithValue("@ID", id);

                    myConnection.Open();
                    int rowsAffected = myDeleteCommand.ExecuteNonQuery();
                    ViewBag.Message = "Success: " + rowsAffected + " rows deleted.";
                }
            }
            catch (Exception err)
            {
                ViewBag.Message = "Error: " + err.Message;
            }

            return View("Index"); // Redirect to the Index view after the deletion
        }

        /*
        public ActionResult similarBikes()
        {
            return View();
        }*/

        //method for getting similar bikes
        public ActionResult SimilarBikes(int? brandId, decimal? price)
        {
            var similarBikes = new List<Product>();

            try
            {
                using (SqlConnection connection = new SqlConnection(Globals.ConnectionString))
                {
                    connection.Open();

                    // Build the query based on the user's inputs
                    string similarBikesQuery = "SELECT * FROM [production].[products] WHERE 1=1";

                    if (brandId.HasValue)
                    {
                        similarBikesQuery += " AND brand_id = @BrandId";
                    }

                    if (price.HasValue)
                    {
                        similarBikesQuery += " AND ABS(list_price - @Price) < 500"; // Price difference within R500
                    }

                    SqlCommand similarBikesCommand = new SqlCommand(similarBikesQuery, connection);

                    if (brandId.HasValue)
                    {
                        similarBikesCommand.Parameters.AddWithValue("@BrandId", brandId.Value);
                    }

                    if (price.HasValue)
                    {
                        similarBikesCommand.Parameters.AddWithValue("@Price", price.Value);
                    }

                    using (SqlDataReader similarReader = similarBikesCommand.ExecuteReader())
                    {
                        while (similarReader.Read())
                        {
                            similarBikes.Add(new Product
                            {
                                ProductId = similarReader.GetInt32(0),
                                ProductName = similarReader.GetString(1),
                                BrandId = similarReader.GetInt32(2),
                                CategoryId = similarReader.GetInt32(3),
                                ModelYear = similarReader.GetInt16(4),
                                ListPrice = similarReader.GetDecimal(5)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Error: " + ex.Message;
            }

            return View(similarBikes); // Return the list of similar bikes to the view
        }

        //view for bike for sale
        public ActionResult BikesForSale()
        {
            return View();
        }

        //this s a method that will retrive all bikes that are listed for sale
        public ActionResult ViewAllBikesForSale(string priceRange = null, int? brandId = null, int? categoryId = null)
        {
            List<BikeForSale> bikesForSale = new List<BikeForSale>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT p.product_id, p.product_name, p.brand_id, b.brand_name, 
                   p.category_id, c.category_name, p.list_price, 
                   oi.quantity, oi.discount
            FROM [sales].[order_items] oi
            JOIN [production].[products] p ON oi.product_id = p.product_id
            JOIN [production].[brands] b ON p.brand_id = b.brand_id
            JOIN [production].[categories] c ON p.category_id = c.category_id
            WHERE (@PriceRange IS NULL OR p.list_price <= @PriceRange)
              AND (@BrandId IS NULL OR p.brand_id = @BrandId)
              AND (@CategoryId IS NULL OR p.category_id = @CategoryId)";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    con.Open();

                    cmd.Parameters.AddWithValue("@PriceRange", string.IsNullOrEmpty(priceRange) ? DBNull.Value : (object)Convert.ToDecimal(priceRange));
                    cmd.Parameters.AddWithValue("@BrandId", brandId.HasValue ? (object)brandId.Value : DBNull.Value);
                    cmd.Parameters.AddWithValue("@CategoryId", categoryId.HasValue ? (object)categoryId.Value : DBNull.Value);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            BikeForSale bike = new BikeForSale
                            {
                                ProductId = Convert.ToInt32(reader["product_id"]),
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                BrandName = reader["brand_name"].ToString(),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                CategoryName = reader["category_name"].ToString(),
                                ListPrice = Convert.ToDecimal(reader["list_price"]),
                                Quantity = Convert.ToInt32(reader["quantity"]),
                                Discount = Convert.ToDecimal(reader["discount"])
                            };
                            bikesForSale.Add(bike);
                        }
                    }

                    ViewBag.Message = bikesForSale.Count > 0
                        ? "Bikes listed for sale:"
                        : "No bikes available for sale.";
                    ViewBag.BikesForSale = bikesForSale.Any() ? bikesForSale : null;
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                    ViewBag.BikesForSale = null;
                }
            }

            return View("BikesForSale");
        }

        /*
       //view to find bikes
       public ActionResult FindBike()
       {
           return View();
       }
        */

        //method that will find the bike based on the provide inputs
        public ActionResult FindBike()
        {
            string connectionString = Globals.ConnectionString;

            List<Brand> brands = new List<Brand>();
            List<Category> categories = new List<Category>();
            List<Store> stores = new List<Store>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // Retrieve Brands
                string brandQuery = "SELECT brand_id, brand_name FROM [production].[brands]";
                SqlCommand brandCmd = new SqlCommand(brandQuery, con);
                using (SqlDataReader reader = brandCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        brands.Add(new Brand
                        {
                            BrandId = Convert.ToInt32(reader["brand_id"]),
                            BrandName = reader["brand_name"].ToString()
                        });
                    }
                }

                // Retrieve Categories
                string categoryQuery = "SELECT category_id, category_name FROM [production].[categories]";
                SqlCommand categoryCmd = new SqlCommand(categoryQuery, con);
                using (SqlDataReader reader = categoryCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Category
                        {
                            CategoryId = Convert.ToInt32(reader["category_id"]),
                            CategoryName = reader["category_name"].ToString()
                        });
                    }
                }

                // Retrieve Stores
                string storeQuery = "SELECT store_id, store_name FROM [sales].[stores]";
                SqlCommand storeCmd = new SqlCommand(storeQuery, con);
                using (SqlDataReader reader = storeCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        stores.Add(new Store
                        {
                            StoreId = Convert.ToInt32(reader["store_id"]),
                            StoreName = reader["store_name"].ToString()
                        });
                    }
                }
            }

            ViewBag.Brands = brands;
            ViewBag.Categories = categories;
            ViewBag.Stores = stores;

            return View();
        }








        //view for bike for sale
        public ActionResult BikeDetails()
        {
            return View();
        }

        //this is the method for diplaying individal bike information
        public ActionResult ViewBikeDetails(int productId)
        {
            BikeDetails bikeDetails = null;
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
                SELECT p.product_id, p.product_name, p.brand_id, p.category_id, p.model_year, p.list_price, b.brand_name, c.category_name
                FROM [production].[products] p
                JOIN [production].[brands] b ON p.brand_id = b.brand_id
                JOIN [production].[categories] c ON p.category_id = c.category_id
                WHERE p.product_id = @ProductId";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.Parameters.AddWithValue("@ProductId", productId);
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            bikeDetails = new BikeDetails
                            {
                                ProductId = Convert.ToInt32(reader["product_id"]),
                                ProductName = reader["product_name"].ToString(),
                                BrandId = Convert.ToInt32(reader["brand_id"]),
                                CategoryId = Convert.ToInt32(reader["category_id"]),
                                ModelYear = Convert.ToInt32(reader["model_year"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"]),
                                //BrandName = reader["brand_name"].ToString(),
                                CategoryName = reader["category_name"].ToString()
                            };
                        }
                    }

                    ViewBag.Message = bikeDetails != null
                        ? "Bike details:"
                        : "Bike not found.";
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                    bikeDetails = null;
                }
            }

            return View("BikeDetails", bikeDetails);
        }

        //method that controles the purchase of the bike 
        [HttpPost]
        public ActionResult IssuePurchaseOrder(int productId, int customerId, int storeId, int staffId, DateTime requiredDate)
        {
            using (SqlConnection myConnection = new SqlConnection(Globals.ConnectionString))
            {
                try
                {
                    myConnection.Open();

                    // Insert into the orders table
                    string orderQuery = @"
                INSERT INTO [BikeStores].[sales].[orders] 
                (customer_id, order_status, order_date, required_date, store_id, staff_id)
                VALUES (@CustomerId, @OrderStatus, @OrderDate, @RequiredDate, @StoreId, @StaffId);
                SELECT SCOPE_IDENTITY();";

                    int orderId;

                    using (SqlCommand myCommand = new SqlCommand(orderQuery, myConnection))
                    {
                        myCommand.Parameters.AddWithValue("@CustomerId", customerId);
                        myCommand.Parameters.AddWithValue("@OrderStatus", 1); // Assuming '1' is the status for new orders
                        myCommand.Parameters.AddWithValue("@OrderDate", DateTime.Now);
                        myCommand.Parameters.AddWithValue("@RequiredDate", requiredDate);
                        myCommand.Parameters.AddWithValue("@StoreId", storeId);
                        myCommand.Parameters.AddWithValue("@StaffId", staffId);

                        orderId = Convert.ToInt32(myCommand.ExecuteScalar());
                    }

                    // Insert into order_items if needed
                    string orderItemQuery = @"
                INSERT INTO [BikeStores].[sales].[order_items] (order_id, product_id, quantity, list_price, discount)
                VALUES (@OrderId, @ProductId, @Quantity, @ListPrice, @Discount);";

                    using (SqlCommand itemCommand = new SqlCommand(orderItemQuery, myConnection))
                    {
                        itemCommand.Parameters.AddWithValue("@OrderId", orderId);
                        itemCommand.Parameters.AddWithValue("@ProductId", productId);
                        itemCommand.Parameters.AddWithValue("@Quantity", 1); // Set to desired quantity
                        itemCommand.Parameters.AddWithValue("@ListPrice", /* Fetch product price from DB if needed */ 0); // Set the actual price
                        itemCommand.Parameters.AddWithValue("@Discount", 0); // Set any discount

                        itemCommand.ExecuteNonQuery();
                    }

                    // Save order ID in session for confirmation later
                    Session["LastOrderId"] = orderId;

                    // Redirect to the confirmation page
                    return RedirectToAction("PurchaseConfirmation");
                }
                catch (Exception ex)
                {
                    // Handle exceptions gracefully
                    ViewBag.Message = $"Error: {ex.Message}";
                    return View();
                }
            }
        }




        //confimation view

        public ActionResult PurchaseConfirmation()
        {
            // Retrieve the orderId from session
            var orderId = Session["LastOrderId"] != null ? Convert.ToInt32(Session["LastOrderId"]) : 0;

            if (orderId == 0)
            {
                ViewBag.Message = "No recent order found.";
                return View();
            }

            // Retrieve order details from the database to show confirmation
            PurchaseConfirmationViewModel orderDetails = null;
            using (SqlConnection con = new SqlConnection(Globals.ConnectionString))
            {
                try
                {
                    con.Open();
                    string query = @"
                SELECT o.order_id, o.order_date, p.product_name, oi.quantity, oi.list_price, oi.discount
                FROM [BikeStores].[sales].[orders] o
                JOIN [BikeStores].[sales].[order_items] oi ON o.order_id = oi.order_id
                JOIN [BikeStores].[production].[products] p ON oi.product_id = p.product_id
                WHERE o.order_id = @OrderId";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@OrderId", orderId);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            orderDetails = new PurchaseConfirmationViewModel
                            {
                                OrderId = Convert.ToInt32(reader["order_id"]),
                                OrderDate = Convert.ToDateTime(reader["order_date"]),
                                ProductName = reader["product_name"].ToString(),
                                Quantity = Convert.ToInt32(reader["quantity"]),
                                ListPrice = Convert.ToDecimal(reader["list_price"]),
                                Discount = Convert.ToDecimal(reader["discount"]),
                            };
                        }
                    }

                    if (orderDetails != null)
                    {
                        ViewBag.Message = "Thank you for your order! Your purchase has been successfully completed at Bicycle Hub.";
                    }
                    else
                    {
                        ViewBag.Message = "Unable to retrieve order details.";
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            // Pass the orderDetails to the view for rendering
            return View(orderDetails);
        }

        //thank you view
        public ActionResult ThankYou()
        {
            return View();
        }

        //my bike view 
        public ActionResult MyBikes()
        {
            /*ViewBag.Message = "Your application description page.";*/

            return View();
        }



        //method that gets all my bikes
        public ActionResult GetBikesBought(int customerId)
        {
            List<BikeViewModel> bikesBought = new List<BikeViewModel>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT o.order_id, p.product_name AS bicycle_name, oi.quantity, oi.list_price, oi.discount, 
                   o.order_date, o.order_status
            FROM BikeStores.sales.orders o
            JOIN BikeStores.sales.order_items oi ON o.order_id = oi.order_id
            JOIN BikeStores.production.products p ON oi.product_id = p.product_id
            WHERE o.customer_id = @customerId
            ORDER BY o.order_date DESC";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.Parameters.AddWithValue("@customerId", customerId);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (!reader.HasRows)
                    {
                        ViewBag.Message = "No bicycles found for this customer.";
                        return View("MyBikes", bikesBought);
                    }

                    while (reader.Read())
                    {
                        BikeViewModel bike = new BikeViewModel
                        {
                            OrderId = Convert.ToInt32(reader["order_id"]),
                            BicycleName = reader["bicycle_name"].ToString(),
                            Quantity = Convert.ToInt32(reader["quantity"]),
                            ListPrice = Convert.ToDecimal(reader["list_price"]),
                            Discount = Convert.ToDecimal(reader["discount"]),
                            OrderDate = Convert.ToDateTime(reader["order_date"]),
                            OrderStatus = reader["order_status"].ToString()
                        };
                        bikesBought.Add(bike);
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            return View("MyBikes", bikesBought);  // Return the view with the data
        }

        public ActionResult GetBikesSold(int staffId)
        {
            List<BikeViewModel> bikesSold = new List<BikeViewModel>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT o.order_id, p.product_name AS bicycle_name, oi.quantity, oi.list_price, oi.discount, 
                   o.order_date, o.order_status
            FROM BikeStores.sales.orders o
            JOIN BikeStores.sales.order_items oi ON o.order_id = oi.order_id
            JOIN BikeStores.production.products p ON oi.product_id = p.product_id
            WHERE o.staff_id = @staffId
            ORDER BY o.order_date DESC";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.Parameters.AddWithValue("@staffId", staffId);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (!reader.HasRows)
                    {
                        ViewBag.Message = "No bicycles found for this staff member.";
                        return View("MyBikes", bikesSold);
                    }

                    while (reader.Read())
                    {
                        BikeViewModel bike = new BikeViewModel
                        {
                            OrderId = Convert.ToInt32(reader["order_id"]),
                            BicycleName = reader["bicycle_name"].ToString(),
                            Quantity = Convert.ToInt32(reader["quantity"]),
                            ListPrice = Convert.ToDecimal(reader["list_price"]),
                            Discount = Convert.ToDecimal(reader["discount"]),
                            OrderDate = Convert.ToDateTime(reader["order_date"]),
                            OrderStatus = reader["order_status"].ToString()
                        };
                        bikesSold.Add(bike);
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            return View("MyBikes", bikesSold);  // Return the view with the data
        }


        //view that will for Bike info
        public ActionResult BikeInfo()
        {
            return View();
        }

        //method that view bike to view bike details
        public ActionResult GetBikeDetails(int orderId)
        {
            BikeDetailsViewModel bikeDetails = null;
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT o.order_id, p.product_name AS bicycle_name, oi.quantity, oi.list_price, oi.discount, 
                   o.order_date, o.order_status, s.store_name, st.first_name, st.last_name
            FROM BikeStores.sales.orders o
            JOIN BikeStores.sales.order_items oi ON o.order_id = oi.order_id
            JOIN BikeStores.production.products p ON oi.product_id = p.product_id
            LEFT JOIN BikeStores.sales.staffs st ON o.staff_id = st.staff_id
            LEFT JOIN BikeStores.sales.stores s ON o.store_id = s.store_id
            WHERE o.order_id = @orderId";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.Parameters.AddWithValue("@orderId", orderId);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        bikeDetails = new BikeDetailsViewModel
                        {
                            OrderId = Convert.ToInt32(reader["order_id"]),
                            BicycleName = reader["bicycle_name"].ToString(),
                            Quantity = Convert.ToInt32(reader["quantity"]),
                            ListPrice = Convert.ToDecimal(reader["list_price"]),
                            Discount = Convert.ToDecimal(reader["discount"]),
                            OrderDate = Convert.ToDateTime(reader["order_date"]),
                            OrderStatus = reader["order_status"].ToString(),
                            StoreName = reader["store_name"].ToString(),
                            StaffFirstName = reader["first_name"]?.ToString(),
                            StaffLastName = reader["last_name"]?.ToString()
                        };
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            if (bikeDetails == null)
            {
                return HttpNotFound();  // Return 404 if no bike details were found
            }

            return View("BikeInfo", bikeDetails);  // Return the BikeInfo view with the data
        }


        //our globally store
        public ActionResult OurStoresglobally()
        {
            return View();
        }

        //method to get bicycle my store
        public ActionResult GetBicyclesByStore(int? storeId)
        {
            if (storeId == null)
            {
                ViewBag.Message = "Store ID is required.";
                return View("Error");
            }

            List<BicycleViewModel> bicycles = new List<BicycleViewModel>();
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT p.product_id, p.product_name AS bicycle_name, s.quantity, p.list_price, p.model_year, 
                   st.first_name, st.last_name, st.email, st.phone
            FROM BikeStores.production.stocks s
            JOIN BikeStores.production.products p ON s.product_id = p.product_id
            LEFT JOIN BikeStores.sales.staffs st ON s.store_id = st.store_id
            WHERE s.store_id = @storeId";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.Parameters.AddWithValue("@storeId", storeId.Value);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        BicycleViewModel bike = new BicycleViewModel
                        {
                            ProductId = Convert.ToInt32(reader["product_id"]),
                            BicycleName = reader["bicycle_name"].ToString(),
                            Quantity = Convert.ToInt32(reader["quantity"]),
                            ListPrice = Convert.ToDecimal(reader["list_price"]),
                            ModelYear = Convert.ToInt32(reader["model_year"]),
                            StaffFirstName = reader["first_name"].ToString(),
                            StaffLastName = reader["last_name"].ToString(),
                            StaffEmail = reader["email"].ToString(),
                            StaffPhone = reader["phone"].ToString()
                        };
                        bicycles.Add(bike);
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            return View("OurStoresglobally", bicycles);
        }




        //view 
        public ActionResult StoreDetails()
        {
            return View();
        }

        //view that will display the store details
        public ActionResult ViewBicycleDetails(int productId)
        {
            BikeViewModel bicycle = null;
            string connectionString = Globals.ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    string sqlQuery = @"
            SELECT p.product_name, p.model_year, p.list_price, st.quantity,
                   s.first_name, s.last_name, s.email, s.phone
            FROM BikeStores.production.products p
            JOIN BikeStores.production.stocks st ON p.product_id = st.product_id
            JOIN BikeStores.sales.staffs s ON st.store_id = s.store_id
            WHERE p.product_id = @ProductId";

                    SqlCommand cmd = new SqlCommand(sqlQuery, con);
                    cmd.Parameters.AddWithValue("@ProductId", productId);

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        bicycle = new BikeViewModel
                        {
                            BicycleName = reader["product_name"].ToString(),
                            ModelYear = Convert.ToInt32(reader["model_year"]),
                            ListPrice = Convert.ToDecimal(reader["list_price"]),
                            Quantity = Convert.ToInt32(reader["quantity"]),
                            StaffFirstName = reader["first_name"].ToString(),
                            StaffLastName = reader["last_name"].ToString(),
                            StaffEmail = reader["email"].ToString(),
                            StaffPhone = reader["phone"].ToString()
                        };
                    }

                    reader.Close();
                    ViewBag.Message = bicycle != null ? "Bicycle details found." : "Bicycle not found.";
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error: {ex.Message}";
                }
            }

            return View("StoreDetails", bicycle);
        }


        //this is a search method
        public ActionResult SearchBicycles(string brandName, int? modelYear)
        {
            string connectionString = Globals.ConnectionString;

            List<BicycleViewModel> bicycles = new List<BicycleViewModel>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // SQL query to search bicycles by brand name and model year
                string query = @"
            SELECT p.product_name, p.model_year, p.list_price, b.brand_name
            FROM [production].[products] p
            INNER JOIN [production].[brands] b ON p.brand_id = b.brand_id
            WHERE (@BrandName IS NULL OR b.brand_name LIKE '%' + @BrandName + '%')
            AND (@ModelYear IS NULL OR p.model_year = @ModelYear)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@BrandName", (object)brandName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ModelYear", (object)modelYear ?? DBNull.Value);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        bicycles.Add(new BicycleViewModel
                        {
                            ProductName = reader["product_name"].ToString(),
                            ModelYear = Convert.ToInt32(reader["model_year"]),
                            ListPrice = Convert.ToDecimal(reader["list_price"]),
                            BrandName = reader["brand_name"].ToString()
                        });
                    }
                }
            }

            return View(bicycles);
        }




    }
}



