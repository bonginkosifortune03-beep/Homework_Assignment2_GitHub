﻿namespace WebApplication5.Controllers
{
    public class GlobalsBase
    {
        /*here i am creating my connection string*/
        public static string ConnectionString = @"Data Source=TLOUBONGINKOSIF\SQLEXPRESS;Initial Catalog=BikeStores;Integrated Security=True;";
    }
}